package com.examportal.services;

import java.util.Set;
import com.examportal.entities.UserRoles;
import com.examportal.entities.user;


public interface UserService {
	//creating user
	public user createUser(user user, Set<UserRoles> userRoles) throws Exception; 
	
	//get user by username
	public user getUser(String username);
	
	//delete user by ID
	public void deleteUser(Long userId);
}
