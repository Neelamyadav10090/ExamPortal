package com.examportal.services.implementation;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examportal.entities.UserRoles;
import com.examportal.entities.user;
import com.examportal.repository.RoleRepository;
import com.examportal.repository.UserRepository;
import com.examportal.services.UserService;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Override
	//creating user
	public user createUser(user user, Set<UserRoles> userRole) throws Exception {
		
		user local = this.userRepository.findByUsername(user.getUsername());
		if(local!=null)
		{
			System.out.println("User is already exit !!");
			throw	 new Exception("User already present !!");
		}else
		{
			//user create
			for(UserRoles ur:userRole)
			{
				roleRepository.save(ur.getRole());
			}
			user.getUserRole().addAll(userRole);
			local = this.userRepository.save(user);
		}
		return local;
	}
	//getting user by username
	@Override
	public user getUser(String username) {
		// TODO Auto-generated method stub
		return this.userRepository.findByUsername(username);
	}
	@Override
	public void deleteUser(Long userId) {
		this.userRepository.deleteById(userId);
		
	}

}
