package com.examportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examportal.entities.user;

public interface UserRepository extends JpaRepository<user, Long> {

	public user findByUsername(String username);
}
