package com.examportal.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class UserRoles {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long roleId;
	
	//User
	@ManyToOne(fetch = FetchType.EAGER)
	private user user;
	
	@ManyToOne
	private Role role;

	public UserRoles() {
		
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRole_Id(long roleId) {
		this.roleId = roleId;
	}

	public user getUser() {
		return user;
	}

	public void setUser(user user) {
		this.user = user;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	
	
	

}
