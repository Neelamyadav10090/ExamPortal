package com.examportal;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.examportal.entities.Role;
import com.examportal.entities.UserRoles;
import com.examportal.entities.user;
import com.examportal.services.UserService;

@SpringBootApplication
public class ExamPortalApplication implements CommandLineRunner {
	@Autowired
	private UserService userService;
	public static void main(String[] args) {
		SpringApplication.run(ExamPortalApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("starting code");
//		user User = new user();
//		User.setFirstName("Neelam");
//		User.setLastName("Yadav");
//		User.setUsername("neelam123");
//		User.setPassword("nee111");
//		User.setEmail("nee@gmail.com");
//		User.setProfile("default.png");
//		User.setPhone("9675657585");
//	
//		Role role1 = new Role();
//		role1.setRoleId(21L);
//		role1.setRoleName("ADMIN");
//		
//		Set<UserRoles> userRoleSet = new HashSet<>();
//		UserRoles userRole = new UserRoles();
//		userRole.setRole(role1);
//		userRole.setUser(User);
//		
//		userRoleSet.add(userRole);
//		
//		user User1 = this.userService.createUser(User, userRoleSet);
//		System.out.println(User1.getUsername());
//		
	}

}
