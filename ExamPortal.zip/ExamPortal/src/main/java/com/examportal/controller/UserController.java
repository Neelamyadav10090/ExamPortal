package com.examportal.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examportal.entities.Role;
import com.examportal.entities.UserRoles;
import com.examportal.entities.user;
import com.examportal.services.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
//creating User
	@PostMapping("/")
	public user createUser(@RequestBody user User) throws Exception
	{
		Set<UserRoles> roles = new HashSet<>();
		Role role1 = new Role();
		role1.setRoleId(21L);
		role1.setRoleName("Normal");
		
		UserRoles userRole = new UserRoles();
		userRole.setUser(User);
		userRole.setRole(role1);
		
		roles.add(userRole);
		
		return this.userService.createUser(User, roles);
	}
	@GetMapping("/{username}")
	public user getUser(@PathVariable("username")String username) 
	{
		return this.userService.getUser(username);
		
	}
	
	//delete the User By Id
	@DeleteMapping("/{userId}")
	public void deleteUser(@PathVariable("userId") Long userId)
	{
		this.userService.deleteUser(userId);
	}
}
